tar -jxvf data.tar.bz2
mkdir dnn_save_path
mkdir dnn_best_model
